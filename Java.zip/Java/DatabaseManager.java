import java.sql.*;

public class DatabaseManager {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/library_db";
    private static final String DB_USER = "your_username"; // Replace with your DB username
    private static final String DB_PASSWORD = "your_password"; // Replace with your DB password
    
    private Connection connection;
    
    // Method to connect to the database
    public void connect() throws SQLException {
        connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD);
        System.out.println("Connected to the database successfully.");
    }
    
    // Method to disconnect from the database
    public void disconnect() {
        if(connection != null) {
            try {
                connection.close();
                System.out.println("Disconnected from the database.");
            } catch(SQLException e) {
                System.out.println("Error disconnecting from the database: " + e.getMessage());
            }
        }
    }
    
    // Method to add a book to the database
    public void addBookToDB(Book book) {
        String sql = "INSERT INTO books (title, author, isbn) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, book.getTitle());
            pstmt.setString(2, book.getAuthor());
            pstmt.setString(3, book.getIsbn());
            pstmt.executeUpdate();
            System.out.println("Book added to the database.");
        } catch(SQLException e) {
            System.out.println("Error adding book to the database: " + e.getMessage());
        }
    }
    
    // Method to retrieve all books from the database
    public void displayAllBooksFromDB() {
        String sql = "SELECT * FROM books";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
                 
            while(rs.next()) {
                System.out.println("ID: " + rs.getInt("id") +
                                   ", Title: " + rs.getString("title") +
                                   ", Author: " + rs.getString("author") +
                                   ", ISBN: " + rs.getString("isbn"));
            }
        } catch(SQLException e) {
            System.out.println("Error retrieving books from the database: " + e.getMessage());
        }
    }
    
    // Additional database methods can be added here (e.g., search, delete)
}
