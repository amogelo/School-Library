import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Library library = new Library();
        DatabaseManager dbManager = new DatabaseManager();
        Scanner scanner = new Scanner(System.in);
        
        // Connect to the database
        try {
            dbManager.connect();
        } catch(Exception e) {
            System.out.println("Failed to connect to the database: " + e.getMessage());
            return;
        }
        
        boolean exit = false;
        while(!exit) {
            System.out.println("\n=== Library Menu ===");
            System.out.println("1. Display all books");
            System.out.println("2. Display all authors");
            System.out.println("3. Sort books");
            System.out.println("4. Add a book");
            System.out.println("5. Search for a book by title");
            System.out.println("6. Search for a book by ISBN");
            System.out.println("7. Create and display citation for a book");
            System.out.println("8. Calculate fine for outstanding book");
            System.out.println("9. Add book to Database");
            System.out.println("10. Display all books from Database");
            System.out.println("0. Exit");
            System.out.print("Choose an option: ");
            
            String choice = scanner.nextLine().trim();
            
            switch(choice) {
                case "1":
                    library.displayAllBooks();
                    break;
                case "2":
                    library.displayAllAuthors();
                    break;
                case "3":
                    System.out.println("Sort by: 1. Title  2. Author");
                    System.out.print("Choose sorting criteria: ");
                    try {
                        int criteria = Integer.parseInt(scanner.nextLine().trim());
                        library.sortBooks(criteria);
                    } catch(NumberFormatException e) {
                        System.out.println("Invalid input.");
                    }
                    break;
                case "4":
                    Book newBook = library.inputBook();
                    if(newBook != null) {
                        library.addBook(newBook);
                    }
                    break;
                case "5":
                    System.out.print("Enter book title to search: ");
                    String title = scanner.nextLine().trim();
                    library.searchBookByTitle(title);
                    break;
                case "6":
                    System.out.print("Enter ISBN to search: ");
                    String isbn = scanner.nextLine().trim();
                    library.searchBookByISBN(isbn);
                    break;
                case "7":
                    System.out.print("Enter ISBN of the book to create citation: ");
                    String citationIsbn = scanner.nextLine().trim();
                    Book citationBook = null;
                    for(Book book : library.books) {
                        if(ISBNUtils.removeDash(book.getIsbn()).equals(ISBNUtils.removeDash(citationIsbn))) {
                            citationBook = book;
                            break;
                        }
                    }
                    if(citationBook != null) {
                        library.displayCitation(citationBook);
                    } else {
                        System.out.println("Book not found for citation.");
                    }
                    break;
                case "8":
                    library.calculateFine();
                    break;
                case "9":
                    System.out.print("Enter ISBN of the book to add to Database: ");
                    String dbIsbn = scanner.nextLine().trim();
                    Book dbBook = null;
                    for(Book book : library.books) {
                        if(ISBNUtils.removeDash(book.getIsbn()).equals(ISBNUtils.removeDash(dbIsbn))) {
                            dbBook = book;
                            break;
                        }
                    }
                    if(dbBook != null) {
                        dbManager.addBookToDB(dbBook);
                    } else {
                        System.out.println("Book not found to add to database.");
                    }
                    break;
                case "10":
                    dbManager.displayAllBooksFromDB();
                    break;
                case "0":
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
        
        // Disconnect from the database
        dbManager.disconnect();
        System.out.println("Exiting the Library System. Goodbye!");
    }
}
