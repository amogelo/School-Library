import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class LibraryGUI extends JFrame {
    private Library library;
    private DatabaseManager dbManager;
    private DefaultTableModel tableModel;
    private JTable table;

    public LibraryGUI() {
        library = new Library();
        dbManager = new DatabaseManager();
        try {
            dbManager.connect();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Database Connection Failed: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }

        setTitle("School Library System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Initialize UI Components
        initComponents();
    }

    private void initComponents() {
        // Create Tabs
        JTabbedPane tabbedPane = new JTabbedPane();

        // Tab 1: Display All Books
        JPanel displayPanel = new JPanel(new BorderLayout());
        tableModel = new DefaultTableModel(new String[]{"ID", "Title", "Author", "ISBN"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        displayPanel.add(scrollPane, BorderLayout.CENTER);
        
        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> loadBooks());
        displayPanel.add(refreshButton, BorderLayout.SOUTH);

        tabbedPane.addTab("Display Books", displayPanel);

        // Tab 2: Add New Book
        JPanel addPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10,10,10,10);
        gbc.anchor = GridBagConstraints.WEST;

        // Title
        gbc.gridx = 0;
        gbc.gridy = 0;
        addPanel.add(new JLabel("Title:"), gbc);
        gbc.gridx = 1;
        JTextField titleField = new JTextField(20);
        addPanel.add(titleField, gbc);

        // Author
        gbc.gridx = 0;
        gbc.gridy = 1;
        addPanel.add(new JLabel("Author:"), gbc);
        gbc.gridx = 1;
        JTextField authorField = new JTextField(20);
        addPanel.add(authorField, gbc);

        // ISBN
        gbc.gridx = 0;
        gbc.gridy = 2;
        addPanel.add(new JLabel("ISBN:"), gbc);
        gbc.gridx = 1;
        JTextField isbnField = new JTextField(20);
        addPanel.add(isbnField, gbc);

        // Add Button
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.CENTER;
        JButton addButton = new JButton("Add Book");
        addPanel.add(addButton, gbc);

        addButton.addActionListener(e -> {
            String title = titleField.getText().trim();
            String author = authorField.getText().trim();
            String isbn = isbnField.getText().trim();

            if(title.isEmpty() || author.isEmpty() || isbn.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required.",
                        "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if(!ISBNUtils.validateISBN(isbn)) {
                JOptionPane.showMessageDialog(this, "Invalid ISBN.",
                        "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Book newBook = new Book(title, author, isbn);
            library.addBook(newBook);
            dbManager.addBookToDB(newBook);
            JOptionPane.showMessageDialog(this, "Book added successfully!",
                    "Success", JOptionPane.INFORMATION_MESSAGE);
            titleField.setText("");
            authorField.setText("");
            isbnField.setText("");
            loadBooks();
        });

        tabbedPane.addTab("Add Book", addPanel);

        // Tab 3: Search Books
        JPanel searchPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbcSearch = new GridBagConstraints();
        gbcSearch.insets = new Insets(10,10,10,10);
        gbcSearch.anchor = GridBagConstraints.WEST;

        // Search by Title
        gbcSearch.gridx = 0;
        gbcSearch.gridy = 0;
        searchPanel.add(new JLabel("Search by Title:"), gbcSearch);
        gbcSearch.gridx = 1;
        JTextField searchTitleField = new JTextField(20);
        searchPanel.add(searchTitleField, gbcSearch);
        gbcSearch.gridx = 2;
        JButton searchTitleButton = new JButton("Search");
        searchPanel.add(searchTitleButton, gbcSearch);

        // Search by ISBN
        gbcSearch.gridx = 0;
        gbcSearch.gridy = 1;
        searchPanel.add(new JLabel("Search by ISBN:"), gbcSearch);
        gbcSearch.gridx = 1;
        JTextField searchIsbnField = new JTextField(20);
        searchPanel.add(searchIsbnField, gbcSearch);
        gbcSearch.gridx = 2;
        JButton searchIsbnButton = new JButton("Search");
        searchPanel.add(searchIsbnButton, gbcSearch);

        // Search Results Table
        DefaultTableModel searchTableModel = new DefaultTableModel(new String[]{"ID", "Title", "Author", "ISBN"}, 0);
        JTable searchTable = new JTable(searchTableModel);
        JScrollPane searchScrollPane = new JScrollPane(searchTable);
        gbcSearch.gridx = 0;
        gbcSearch.gridy = 2;
        gbcSearch.gridwidth = 3;
        gbcSearch.fill = GridBagConstraints.BOTH;
        gbcSearch.weightx = 1.0;
        gbcSearch.weighty = 1.0;
        searchPanel.add(searchScrollPane, gbcSearch);

        // Search by Title Action
        searchTitleButton.addActionListener(e -> {
            String title = searchTitleField.getText().trim();
            if(title.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a title to search.",
                        "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            searchTableModel.setRowCount(0); // Clear previous results
            for(Book book : library.books) {
                if(book.getTitle().equalsIgnoreCase(title)) {
                    searchTableModel.addRow(new Object[]{book.getId(), book.getTitle(), book.getAuthor(), book.getIsbn()});
                }
            }
            if(searchTableModel.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "No books found with the title \"" + title + "\".",
                        "No Results", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        // Search by ISBN Action
        searchIsbnButton.addActionListener(e -> {
            String isbn = searchIsbnField.getText().trim();
            if(isbn.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter an ISBN to search.",
                        "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            searchTableModel.setRowCount(0); // Clear previous results
            for(Book book : library.books) {
                if(ISBNUtils.removeDash(book.getIsbn()).equalsIgnoreCase(ISBNUtils.removeDash(isbn))) {
                    searchTableModel.addRow(new Object[]{book.getId(), book.getTitle(), book.getAuthor(), book.getIsbn()});
                }
            }
            if(searchTableModel.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "No books found with the ISBN \"" + isbn + "\".",
                        "No Results", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        tabbedPane.addTab("Search Books", searchPanel);

        // Add Tabbed Pane to Frame
        add(tabbedPane, BorderLayout.CENTER);

        // Load initial data
        loadBooks();
    }

    private void loadBooks() {
        tableModel.setRowCount(0); // Clear existing data
        for(Book book : library.books) {
            tableModel.addRow(new Object[]{book.getId(), book.getTitle(), book.getAuthor(), book.getIsbn()});
        }
    }

    // Main method to run the GUI
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LibraryGUI gui = new LibraryGUI();
            gui.setVisible(true);
        });
    }
}
