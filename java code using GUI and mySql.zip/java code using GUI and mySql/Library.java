import java.io.*;
import java.util.*;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class Library {
    List<Book> books; // Changed to package-private for GUI access
    private final String fileName = "books.txt";
    private DatabaseManager dbManager;

    public Library() {
        books = new ArrayList<>();
        dbManager = new DatabaseManager();
        loadBooksFromDB();
        // Optionally load from file
        // loadBooksFromFile();
    }
    
    // Load books from the database
    private void loadBooksFromDB() {
        books = dbManager.getAllBooksFromDB();
    }

    // Existing methods...
    
    // Add a book to the library and the database
    public void addBook(Book book) {
        books.add(book);
        dbManager.addBookToDB(book);
        // Optionally save to file
        // saveBooksToFile();
        System.out.println("Book added successfully.");
    }
    
    // Other methods remain unchanged...
}
